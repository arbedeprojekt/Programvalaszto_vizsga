<!DOCTYPE html>
<html>
<head>
    <title>Email Visszaigazolás</title>
</head>
<body>
    <h1>Visszaigazoló E-mail</h1>
    <p>Kérjük, kattintson az alábbi linkre az e-mail címének ellenőrzéséhez:</p>
    <a href="{{ $verificationUrl }}">E-mail cím ellenőrzés</a>
</body>
</html>