<!DOCTYPE html>
<html>
<head>
    <title>Email Visszaigazolás</title>
</head>
<body>
    <h1>Visszaigazoló E-mail</h1>
    <p>Kérjük, kattintson az alábbi linkre az e-mail címének ellenőrzéséhez:</p>
    <a href="<?php echo e($verificationUrl); ?>">E-mail cím ellenőrzés</a>
</body>
</html><?php /**PATH E:\ffff\Backend14\resources\views/emails/verify.blade.php ENDPATH**/ ?>